# One-time setup. Run from the CampusMate_AI folder:  .\setup.ps1
$ErrorActionPreference = "Stop"
Write-Host "== CampusMate AI setup ==" -ForegroundColor Cyan
if (-not (Get-Command python -ErrorAction SilentlyContinue)) { throw "Python not found. Install Python 3.10-3.12 from python.org (tick 'Add to PATH')." }
if (-not (Get-Command npm -ErrorAction SilentlyContinue)) { throw "Node.js not found. Install the LTS version from nodejs.org." }

if (-not (Test-Path ".env")) { Copy-Item ".env.example" ".env"; Write-Host "Created .env - open it and add your NEXUS settings." -ForegroundColor Yellow }

Push-Location backend
if (-not (Test-Path "venv")) { python -m venv venv }
& .\venv\Scripts\python.exe -m pip install --upgrade pip
& .\venv\Scripts\python.exe -m pip install -r requirements.txt
& .\venv\Scripts\python.exe manage.py migrate
Write-Host "`nCreate the ADMIN account (choose a strong password):" -ForegroundColor Cyan
& .\venv\Scripts\python.exe manage.py createsuperuser
Pop-Location

Push-Location frontend
npm install
Pop-Location
Write-Host "`nSetup complete. Edit .env, then run .\run_backend.ps1 and .\run_frontend.ps1 in two terminals." -ForegroundColor Green
