import hashlib
import os
from datetime import timedelta
from django.conf import settings
from django.db.models import Count
from django.db.models.functions import TruncDate
from django.shortcuts import get_object_or_404
from django.utils import timezone
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAdminUser
from rest_framework.parsers import MultiPartParser, FormParser
from chatbot.models import ChatMessage
from rag import pipeline
from .models import Document, Chunk, CATEGORIES

ALLOWED_EXT = {".pdf", ".docx", ".txt", ".csv", ".xlsx"}
CATEGORY_LABELS = dict(CATEGORIES)


def serialize(d):
    return {
        "id": d.id, "name": d.name, "category": d.category,
        "category_label": CATEGORY_LABELS.get(d.category, d.category),
        "status": d.status, "error": d.error, "chunk_count": d.chunk_count,
        "uploaded_at": d.uploaded_at, "indexed_at": d.indexed_at,
    }


def validate_file(f):
    """Returns an error string, or None if the file is acceptable."""
    ext = os.path.splitext(f.name)[1].lower()
    if ext not in ALLOWED_EXT:
        return f"Unsupported file type '{ext}'. Allowed: PDF, DOCX, TXT, CSV, XLSX."
    if f.size > settings.MAX_UPLOAD_MB * 1024 * 1024:
        return f"File exceeds the {settings.MAX_UPLOAD_MB} MB limit."
    if f.size == 0:
        return "File is empty."
    return None


def file_digest(f):
    h = hashlib.sha256()
    for chunk in f.chunks():
        h.update(chunk)
    f.seek(0)
    return h.hexdigest()


class AdminBase(APIView):
    authentication_classes = [TokenAuthentication]
    permission_classes = [IsAdminUser]


class CategoriesView(APIView):
    def get(self, request):
        return Response([{"value": v, "label": l} for v, l in CATEGORIES])


class DocumentListUploadView(AdminBase):
    parser_classes = [MultiPartParser, FormParser]

    def get(self, request):
        return Response([serialize(d) for d in Document.objects.all()])

    def post(self, request):
        category = request.data.get("category", "")
        if category not in CATEGORY_LABELS:
            return Response({"error": "A valid category is required."}, status=400)
        files = request.FILES.getlist("file")
        if not files:
            return Response({"error": "No file uploaded."}, status=400)
        results = []
        for f in files:
            err = validate_file(f)
            if err:
                results.append({"name": f.name, "ok": False, "error": err})
                continue
            digest = file_digest(f)
            if Document.objects.filter(file_hash=digest).exists():
                results.append({"name": f.name, "ok": False,
                                "error": "This document is already indexed (duplicate)."})
                continue
            doc = Document.objects.create(name=os.path.basename(f.name)[:200], file=f,
                                          category=category, file_hash=digest)
            pipeline.index_document(doc)
            results.append({"name": doc.name, "ok": doc.status == "indexed",
                            "error": doc.error, "document": serialize(doc)})
        ok = any(r["ok"] for r in results)
        dup_only = all("duplicate" in (r.get("error") or "") for r in results)
        return Response({"results": results}, status=201 if ok else (409 if dup_only else 400))


class DocumentDetailView(AdminBase):
    def delete(self, request, pk):
        doc = get_object_or_404(Document, pk=pk)
        pipeline.delete_document_vectors(doc)
        doc.file.delete(save=False)
        doc.delete()
        return Response(status=204)


class DocumentReindexView(AdminBase):
    """Re-index a document. Optionally upload a replacement file (updated version)."""
    parser_classes = [MultiPartParser, FormParser]

    def post(self, request, pk):
        doc = get_object_or_404(Document, pk=pk)
        new_file = request.FILES.get("file")
        if new_file:
            err = validate_file(new_file)
            if err:
                return Response({"error": err}, status=400)
            digest = file_digest(new_file)
            if Document.objects.filter(file_hash=digest).exclude(pk=doc.pk).exists():
                return Response({"error": "That file is already indexed as another document."}, status=409)
            doc.file.delete(save=False)
            doc.file = new_file
            doc.name = os.path.basename(new_file.name)[:200]
            doc.file_hash = digest
            doc.save()
        pipeline.index_document(doc)
        return Response(serialize(doc))


class DocumentStatusView(AdminBase):
    def get(self, request, pk):
        return Response(serialize(get_object_or_404(Document, pk=pk)))


class StatsView(AdminBase):
    def get(self, request):
        since = timezone.now() - timedelta(days=6)
        per_day = (ChatMessage.objects.filter(created_at__date__gte=since.date())
                   .annotate(day=TruncDate("created_at")).values("day")
                   .annotate(n=Count("id")).order_by("day"))
        by_cat = Document.objects.values("category").annotate(n=Count("id"))
        total_q = ChatMessage.objects.count()
        answered = ChatMessage.objects.filter(answered=True).count()
        return Response({
            "documents_total": Document.objects.count(),
            "documents_indexed": Document.objects.filter(status="indexed").count(),
            "documents_failed": Document.objects.filter(status="failed").count(),
            "chunks_total": Chunk.objects.count(),
            "queries_total": total_q,
            "queries_answered": answered,
            "queries_unanswered": total_q - answered,
            "queries_per_day": [{"day": str(r["day"]), "count": r["n"]} for r in per_day],
            "documents_by_category": [
                {"category": CATEGORY_LABELS.get(r["category"], r["category"]), "count": r["n"]} for r in by_cat],
        })
