import re
from django.db import connection
from rest_framework.views import APIView
from rest_framework.response import Response
from documents.models import Document, Chunk, CATEGORIES
from nexus import client as nexus
from rag import pipeline, store
from .models import ChatMessage

NOT_FOUND = ("I couldn't find this information in the available college documents. "
             "Please contact the concerned department for confirmation.")
SYSTEM_PROMPT = (
    "You are CampusMate AI, a college information assistant. Answer the student's question using ONLY "
    "the provided context excerpts from official college documents. Do not use outside knowledge and do "
    "not guess. Be concise and clear. If the context does not contain the answer, reply with exactly: "
    + NOT_FOUND)
SESSION_RE = re.compile(r"^[A-Za-z0-9_-]{8,64}$")
VALID_CATEGORIES = {v for v, _ in CATEGORIES}


def build_sources(hits):
    seen, out = set(), []
    for chunk, score in hits:
        key = (chunk.document_id, chunk.page, chunk.section)
        if key in seen:
            continue
        seen.add(key)
        out.append({"document": chunk.document.name, "category": chunk.document.get_category_display(),
                    "page": chunk.page, "section": chunk.section, "score": round(score, 3)})
    return out


class ChatView(APIView):
    authentication_classes = []

    def post(self, request):
        question = str(request.data.get("question", "")).strip()
        session_id = str(request.data.get("session_id", "")).strip()
        category = str(request.data.get("category", "") or "").strip()
        if not question or len(question) > 1000:
            return Response({"error": "Question must be between 1 and 1000 characters."}, status=400)
        if not SESSION_RE.match(session_id):
            return Response({"error": "A valid session_id is required."}, status=400)
        if category and category not in VALID_CATEGORIES:
            return Response({"error": "Unknown category."}, status=400)

        try:
            hits = pipeline.retrieve(question, category or None)
        except Exception:  # noqa: BLE001
            return Response({"error": "The knowledge base is unavailable right now.",
                             "code": "retrieval_failed"}, status=503)

        if not hits:  # nothing relevant: never call the LLM, never invent an answer
            answer, sources, answered = NOT_FOUND, [], False
        else:
            context = "\n\n".join(
                f"[Source: {c.document.name}"
                f"{', page ' + str(c.page) if c.page else ''}"
                f"{', ' + c.section if c.section else ''}]\n{c.text}" for c, _ in hits)
            user_prompt = f"Context:\n{context}\n\nStudent question: {question}\n\nAnswer:"
            try:
                answer = nexus.generate(SYSTEM_PROMPT, user_prompt)
            except nexus.NexusError as e:
                return Response({"error": e.message, "code": e.code}, status=e.status)
            answered = not answer.strip().startswith("I couldn't find this information")
            sources = build_sources(hits) if answered else []
            if not answered:
                answer = NOT_FOUND

        ChatMessage.objects.create(session_id=session_id, question=question, answer=answer,
                                   sources=sources, answered=answered)
        return Response({"answer": answer, "sources": sources, "answered": answered})


class HistoryView(APIView):
    authentication_classes = []

    def _sid(self, request):
        sid = request.query_params.get("session_id", "")
        return sid if SESSION_RE.match(sid) else None

    def get(self, request):
        sid = self._sid(request)
        if not sid:
            return Response({"error": "A valid session_id is required."}, status=400)
        msgs = ChatMessage.objects.filter(session_id=sid).order_by("-id")[:50]
        return Response([{"question": m.question, "answer": m.answer, "sources": m.sources,
                          "answered": m.answered, "created_at": m.created_at} for m in reversed(list(msgs))])

    def delete(self, request):
        sid = self._sid(request)
        if not sid:
            return Response({"error": "A valid session_id is required."}, status=400)
        ChatMessage.objects.filter(session_id=sid).delete()
        return Response(status=204)


class HealthView(APIView):
    authentication_classes = []

    def get(self, request):
        try:
            with connection.cursor() as cur:
                cur.execute("SELECT 1")
            db = "ok"
        except Exception:  # noqa: BLE001
            db = "error"
        return Response({"status": "ok" if db == "ok" else "degraded", "database": db,
                         "documents": Document.objects.count(), "chunks": Chunk.objects.count(),
                         "vectors": store.total_vectors(), "nexus_configured": nexus.is_configured()})
