Uploaded documents are stored here (knowledge_base/uploads/) by the Admin Dashboard.
Sample, clearly-labelled fictional test files are in knowledge_base/samples/.
