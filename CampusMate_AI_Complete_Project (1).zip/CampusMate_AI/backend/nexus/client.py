"""
Nexus API adapter. EVERY detail of the Nexus API (base URL, endpoint, model, auth header,
request style, response path) comes from environment variables, because the exact Nexus
specification must be confirmed from your college's Nexus documentation.
"""
import json
import requests
from django.conf import settings


class NexusError(Exception):
    def __init__(self, message, code="nexus_error", status=502):
        super().__init__(message)
        self.message, self.code, self.status = message, code, status


def is_configured():
    s = settings
    key = (s.NEXUS_API_KEY or "").strip()
    return bool(key and not key.lower().startswith("your_") and s.NEXUS_BASE_URL and s.NEXUS_CHAT_ENDPOINT)


def _dig(data, path):
    cur = data
    for part in path.split("."):
        cur = cur[int(part)] if isinstance(cur, list) else cur[part]
    return cur


def generate(system_prompt, user_prompt):
    s = settings
    if not is_configured():
        raise NexusError("Nexus API is not configured. Set NEXUS_API_KEY, NEXUS_BASE_URL and "
                         "NEXUS_CHAT_ENDPOINT in the .env file and restart the backend.",
                         "not_configured", 503)
    url = s.NEXUS_BASE_URL.rstrip("/") + "/" + s.NEXUS_CHAT_ENDPOINT.lstrip("/")
    headers = {"Content-Type": "application/json",
               s.NEXUS_AUTH_HEADER: f"{s.NEXUS_AUTH_PREFIX}{s.NEXUS_API_KEY}".strip()}
    body = {}
    if s.NEXUS_MODEL:
        body["model"] = s.NEXUS_MODEL
    if s.NEXUS_REQUEST_STYLE == "prompt":
        body["prompt"] = f"{system_prompt}\n\n{user_prompt}"
    else:
        body["messages"] = [{"role": "system", "content": system_prompt},
                            {"role": "user", "content": user_prompt}]
    try:
        body.update(json.loads(s.NEXUS_EXTRA_BODY or "{}"))
    except ValueError:
        raise NexusError("NEXUS_EXTRA_BODY in .env is not valid JSON.", "bad_config", 500)

    try:
        resp = requests.post(url, headers=headers, json=body, timeout=s.NEXUS_TIMEOUT)
    except requests.exceptions.Timeout:
        raise NexusError("The Nexus API timed out. Please try again.", "timeout", 504)
    except requests.exceptions.RequestException:
        raise NexusError("Could not reach the Nexus API. Check your network and NEXUS_BASE_URL.",
                         "network_error", 503)

    if resp.status_code in (401, 403):
        raise NexusError("The Nexus API rejected the API key (invalid or unauthorised).", "invalid_api_key", 502)
    if resp.status_code == 429:
        raise NexusError("Nexus API rate limit reached. Please try again shortly.", "rate_limited", 429)
    if resp.status_code >= 500:
        raise NexusError("The Nexus service is temporarily unavailable.", "service_unavailable", 503)
    if resp.status_code >= 400:
        raise NexusError(f"Nexus API returned an error (HTTP {resp.status_code}). Check model name/endpoint.",
                         "bad_request", 502)
    try:
        text = _dig(resp.json(), s.NEXUS_RESPONSE_PATH)
        if not isinstance(text, str) or not text.strip():
            raise ValueError("empty")
        return text.strip()
    except (ValueError, KeyError, IndexError, TypeError):
        raise NexusError("Unexpected Nexus response format. Adjust NEXUS_RESPONSE_PATH in .env.",
                         "bad_response", 502)
