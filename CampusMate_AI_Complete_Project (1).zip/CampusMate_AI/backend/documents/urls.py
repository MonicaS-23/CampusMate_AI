from django.urls import path
from . import views

urlpatterns = [
    path("categories/", views.CategoriesView.as_view()),
    path("admin/documents/", views.DocumentListUploadView.as_view()),
    path("admin/documents/<int:pk>/", views.DocumentDetailView.as_view()),
    path("admin/documents/<int:pk>/reindex/", views.DocumentReindexView.as_view()),
    path("admin/documents/<int:pk>/status/", views.DocumentStatusView.as_view()),
    path("admin/stats/", views.StatsView.as_view()),
]
