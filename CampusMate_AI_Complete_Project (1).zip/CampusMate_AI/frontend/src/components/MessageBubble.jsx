export default function MessageBubble({ role, text, sources, error }) {
  return (
    <div className={`msg ${role}`}>
      <div className="avatar">{role === "user" ? "You" : "AI"}</div>
      <div className={`bubble ${error ? "error" : ""}`}>
        <div className="text">{text}</div>
        {sources && sources.length > 0 && (
          <div className="sources">
            <strong>Sources</strong>
            <ul>
              {sources.map((s, i) => (
                <li key={i}>
                  {s.document}
                  {s.page ? ` — page ${s.page}` : ""}
                  {s.section ? ` — ${s.section}` : ""}
                  <span className="cat"> ({s.category})</span>
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>
    </div>
  );
}
