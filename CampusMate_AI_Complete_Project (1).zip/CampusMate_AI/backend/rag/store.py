"""FAISS vector store persisted in /vector_store. Vector ids == Chunk primary keys."""
import threading
from pathlib import Path
import faiss
import numpy as np
from django.conf import settings

_lock = threading.Lock()


def _path():
    p = Path(settings.VECTOR_DIR)
    p.mkdir(parents=True, exist_ok=True)
    return p / "index.faiss"


def _load(dim=None):
    p = _path()
    if p.exists():
        return faiss.read_index(str(p))
    if dim is None:
        return None
    return faiss.IndexIDMap(faiss.IndexFlatIP(dim))


def add(ids, vectors):
    with _lock:
        idx = _load(vectors.shape[1])
        idx.add_with_ids(vectors, np.asarray(ids, dtype="int64"))
        faiss.write_index(idx, str(_path()))


def remove(ids):
    ids = list(ids)
    if not ids:
        return
    with _lock:
        idx = _load()
        if idx is None:
            return
        idx.remove_ids(np.asarray(ids, dtype="int64"))
        faiss.write_index(idx, str(_path()))


def search(vector, k):
    with _lock:
        idx = _load()
    if idx is None or idx.ntotal == 0:
        return []
    scores, ids = idx.search(np.asarray(vector, dtype="float32").reshape(1, -1), min(k, idx.ntotal))
    return [(int(i), float(s)) for i, s in zip(ids[0], scores[0]) if i != -1]


def total_vectors():
    idx = _load()
    return 0 if idx is None else int(idx.ntotal)
