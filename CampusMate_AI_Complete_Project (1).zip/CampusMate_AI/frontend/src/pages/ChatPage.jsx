import { useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { api } from "../services/api.js";
import MessageBubble from "../components/MessageBubble.jsx";
import Typing from "../components/Typing.jsx";
import SuggestedQuestions from "../components/SuggestedQuestions.jsx";

export default function ChatPage() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [categories, setCategories] = useState([]);
  const [category, setCategory] = useState("");
  const endRef = useRef(null);

  useEffect(() => {
    api.categories().then(setCategories).catch(() => {});
    api.history().then((h) => {
      const list = [];
      h.forEach((m) => {
        list.push({ role: "user", text: m.question });
        list.push({ role: "ai", text: m.answer, sources: m.sources });
      });
      setMessages(list);
    }).catch(() => {});
  }, []);

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages, loading]);

  async function send(text) {
    const q = (text ?? input).trim();
    if (!q || loading) return;
    setInput("");
    setMessages((m) => [...m, { role: "user", text: q }]);
    setLoading(true);
    try {
      const r = await api.ask(q, category);
      setMessages((m) => [...m, { role: "ai", text: r.answer, sources: r.sources }]);
    } catch (e) {
      setMessages((m) => [...m, { role: "ai", text: e.message, error: true }]);
    } finally {
      setLoading(false);
    }
  }

  async function clear() {
    try { await api.clearHistory(); } catch { /* ignore */ }
    setMessages([]);
  }

  return (
    <div className="page chat-page">
      <header className="topbar">
        <div className="brand"><span className="logo">C</span> CampusMate AI <small>Smart College Information Assistant</small></div>
        <div className="top-actions">
          <select value={category} onChange={(e) => setCategory(e.target.value)} aria-label="Category filter">
            <option value="">All topics</option>
            {categories.map((c) => <option key={c.value} value={c.value}>{c.label}</option>)}
          </select>
          <button className="btn ghost" onClick={clear} disabled={!messages.length}>Clear chat</button>
          <Link className="btn ghost" to="/admin/login">Admin</Link>
        </div>
      </header>

      <main className="chat-area">
        {messages.length === 0 ? (
          <div className="welcome">
            <div className="logo big">C</div>
            <h1>Welcome to CampusMate AI</h1>
            <p>Ask anything about college rules, procedures, timetables and services. Answers come from official college documents.</p>
            <SuggestedQuestions onPick={send} disabled={loading} />
          </div>
        ) : (
          <div className="messages">
            {messages.map((m, i) => <MessageBubble key={i} {...m} />)}
            {loading && <Typing />}
            <div ref={endRef} />
          </div>
        )}
      </main>

      <footer className="composer">
        <input
          value={input}
          maxLength={1000}
          placeholder="Type your question…"
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && send()}
          disabled={loading}
        />
        <button className="btn primary" onClick={() => send()} disabled={loading || !input.trim()}>Send</button>
      </footer>
    </div>
  );
}
