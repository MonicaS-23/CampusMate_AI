# CampusMate AI – Smart College Information & Student Support Assistant

A RAG chatbot. Admins upload college documents → text is extracted, chunked, embedded (Sentence Transformers) and stored in FAISS → students ask questions → the most relevant chunks plus the question go to the **Nexus LLM API** (backend only) → the answer is shown with source document names and page numbers.

**Stack:** React + Vite · Django REST · SQLite · FAISS · Sentence Transformers · LangChain text splitters · pypdf / python-docx / pandas + openpyxl.

```
CampusMate_AI/
├─ frontend/          React app (chat, admin login, admin dashboard)
├─ backend/
│  ├─ config/         Django settings & URLs
│  ├─ authentication/ Admin login (token auth, staff users only)
│  ├─ documents/      Document/Chunk models; upload, delete, re-index, stats APIs
│  ├─ chatbot/        Chat, history, health APIs (+ tests.py)
│  ├─ rag/            extract.py, embeddings.py, store.py (FAISS), pipeline.py
│  └─ nexus/          client.py – configurable Nexus API adapter
├─ knowledge_base/    uploads/ (your documents) and samples/ (FICTIONAL test files)
├─ vector_store/      FAISS index (auto-created)
└─ .env.example, .gitignore, setup.ps1, run_backend.ps1, run_frontend.ps1
```

## 1. Prerequisites (Windows)
- **Python 3.10 – 3.12** (python.org; tick *Add Python to PATH*)
- **Node.js LTS** (nodejs.org) and **VS Code**
- Internet on first run (PyTorch download plus a ~90 MB embedding model, downloaded once).

## 2. Install (PowerShell, inside the `CampusMate_AI` folder)
```powershell
Set-ExecutionPolicy -Scope Process Bypass     # allows scripts for this window only
.\setup.ps1
```
It creates `.env`, a virtual environment, installs packages, migrates the database, asks you to create the **admin username/password**, and runs `npm install`.

Manual equivalent: `cd backend; python -m venv venv; .\venv\Scripts\activate; pip install -r requirements.txt; python manage.py migrate; python manage.py createsuperuser`, then `cd ..\frontend; npm install`.

## 3. Enter your Nexus API key and settings
Open `.env` in VS Code and fill in:

| Variable | What to put |
|---|---|
| `NEXUS_API_KEY` | Your key from the college |
| `NEXUS_BASE_URL` | Base URL from the Nexus documentation |
| `NEXUS_CHAT_ENDPOINT` | Chat/completion path from the documentation |
| `NEXUS_MODEL` | Model name from the documentation |
| `NEXUS_AUTH_HEADER` / `NEXUS_AUTH_PREFIX` | How the key is sent (default `Authorization` / `Bearer `) |
| `NEXUS_REQUEST_STYLE` | `messages` (chat-style) or `prompt` (single text field) |
| `NEXUS_RESPONSE_PATH` | Dot-path to the answer in the JSON reply (default `choices.0.message.content`) |
| `NEXUS_EXTRA_BODY` | Optional extra JSON fields, e.g. `{"temperature":0.2}` |

**Pre-filled:** `NEXUS_BASE_URL=https://nexusapi.navigatelabs.ai`, `NEXUS_CHAT_ENDPOINT=/v1/chat/completions` and `NEXUS_MODEL=gemini-2.5-flash`. The Nexus status page describes the API as OpenAI-compatible and gives `gemini-2.5-flash` as its example model, but it does not show the exact endpoint path, and this was **not tested against the real Nexus API**. Get your key from Nexus AI Platform → Model Hub → Key Management. If you get HTTP 404, change the endpoint to `/chat/completions`; if the model is rejected, copy a model name from Model Hub. If the response shape differs, only `backend/nexus/client.py` needs a change. Never share `.env`; the key never reaches the browser. Restart the backend after editing `.env`.

Check: open http://127.0.0.1:8000/api/health/ and look for `"nexus_configured": true`.

## 4. Run (two PowerShell windows)
```powershell
.\run_backend.ps1     # http://127.0.0.1:8000
.\run_frontend.ps1    # http://localhost:5173
```
- Student chatbot: http://localhost:5173
- Admin login: http://localhost:5173/admin/login (account created during setup)

## 5. Upload documents
1. Admin dashboard → choose a **category** → select files (PDF, DOCX, TXT, CSV, XLSX; max 20 MB) → **Upload & index**.
2. The **first** upload downloads the embedding model, so wait a few minutes. Status becomes *indexed*.
3. Try `knowledge_base/samples/` first (**fictional sample data**), then **delete them** and upload real documents.
4. **Re-index** reprocesses a file; **Replace file** uploads an updated version and re-indexes; **Delete** removes the file and its embeddings. Identical files are rejected as duplicates.
5. Scanned (image-only) PDFs have no text and will show *failed*. Run OCR first.

## 6. How answers are produced
Question → embedding → FAISS search → chunks below `SIMILARITY_THRESHOLD` dropped (optional category filter) → if nothing remains, the bot replies *"I couldn't find this information in the available college documents. Please contact the concerned department for confirmation."* **without calling the LLM** → otherwise chunks + question go to Nexus with an instruction to answer only from the context.

Tuning: raise `SIMILARITY_THRESHOLD` (e.g. 0.40) if answers drift off-topic; lower it (e.g. 0.20) if good questions get "couldn't find".

## 7. API summary
`POST /api/chat/` · `GET|DELETE /api/chat/history/?session_id=` · `GET /api/health/` · `GET /api/categories/` · `POST /api/auth/login|logout/` · `GET /api/auth/me/` · admin token required: `GET|POST /api/admin/documents/` · `DELETE /api/admin/documents/<id>/` · `POST /api/admin/documents/<id>/reindex/` · `GET /api/admin/documents/<id>/status/` · `GET /api/admin/stats/`

## 8. Security notes
Key only in backend `.env` (git-ignored) · admin routes need a staff token · passwords hashed by Django · file type/size validated · CORS limited to frontend origins · login and chat rate-limited. For real deployment set `DJANGO_DEBUG=False`, a strong `DJANGO_SECRET_KEY`, and use HTTPS.

## 9. Tests
```powershell
cd backend ; .\venv\Scripts\python.exe manage.py test
```
10 tests cover auth/permissions, extraction of all 5 formats, upload validation, duplicates, FAISS indexing, retrieval, chat with sources and PDF page numbers, unknown questions, Nexus error handling, delete and re-index. They use a lightweight keyword embedder and a local mock Nexus server, so they run offline and do **not** test the real Sentence-Transformers model or the real Nexus API.

## 10. Troubleshooting
| Problem | Fix |
|---|---|
| `running scripts is disabled` | `Set-ExecutionPolicy -Scope Process Bypass` |
| `python` / `npm` not recognised | Install them and reopen PowerShell |
| `pip install` fails on faiss/torch | Use 64-bit Python 3.10–3.12; run `python -m pip install --upgrade pip` |
| "Cannot reach the server" in chat | Backend not running: start `run_backend.ps1` |
| "Nexus API is not configured" | Fill `NEXUS_*` in `.env`, restart backend |
| "rejected the API key" | Wrong/expired key, or wrong auth header/prefix |
| "Unexpected Nexus response format" | Fix `NEXUS_RESPONSE_PATH` or `NEXUS_REQUEST_STYLE` |
| "Nexus API returned an error (HTTP 4xx)" | Check `NEXUS_MODEL`, endpoint path, `NEXUS_EXTRA_BODY` |
| "knowledge base is unavailable" | Embedding model failed to load (no internet on first run?); see backend window |
| Upload shows *failed* | Read the message under the status; scanned PDFs need OCR |
| Always "couldn't find this information" | Lower `SIMILARITY_THRESHOLD`; confirm document is *indexed*; clear the category filter |
| Reset everything | Stop servers; delete `backend/db.sqlite3`, `vector_store/index.faiss`, `knowledge_base/uploads/`; rerun `migrate` + `createsuperuser` |
