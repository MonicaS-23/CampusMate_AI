"""Sentence Transformers embeddings (model is loaded lazily on first use)."""
import threading
import numpy as np
from django.conf import settings

_model = None
_lock = threading.Lock()


def _get_model():
    global _model
    with _lock:
        if _model is None:
            from sentence_transformers import SentenceTransformer
            _model = SentenceTransformer(settings.EMBEDDING_MODEL)
    return _model


def embed(texts):
    """Returns an L2-normalised float32 matrix (cosine similarity == inner product)."""
    vecs = _get_model().encode(list(texts), normalize_embeddings=True, show_progress_bar=False)
    return np.asarray(vecs, dtype="float32")
