SAMPLE DOCUMENT (FICTIONAL DATA FOR TESTING ONLY - NOT REAL COLLEGE INFORMATION)

Upload these from the Admin Dashboard to test the chatbot. Delete them before uploading real documents.
Suggested categories: attendance_rules, contact_information, placement_guidelines, academic_regulations, timetables.
