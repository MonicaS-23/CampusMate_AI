Push-Location "$PSScriptRoot\backend"
& .\venv\Scripts\python.exe manage.py migrate
& .\venv\Scripts\python.exe manage.py runserver 127.0.0.1:8000
Pop-Location
