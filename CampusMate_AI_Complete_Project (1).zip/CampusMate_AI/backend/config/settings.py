import os
from pathlib import Path
from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent.parent
ROOT_DIR = BASE_DIR.parent
load_dotenv(ROOT_DIR / ".env")


def env(name, default=""):
    return os.getenv(name, default)


SECRET_KEY = env("DJANGO_SECRET_KEY", "dev-insecure-key-change-me")
DEBUG = env("DJANGO_DEBUG", "True").lower() == "true"
ALLOWED_HOSTS = [h.strip() for h in env("ALLOWED_HOSTS", "localhost,127.0.0.1,testserver").split(",")]

INSTALLED_APPS = [
    "django.contrib.admin", "django.contrib.auth", "django.contrib.contenttypes",
    "django.contrib.sessions", "django.contrib.messages", "django.contrib.staticfiles",
    "rest_framework", "rest_framework.authtoken", "corsheaders",
    "documents", "chatbot",
]
MIDDLEWARE = [
    "corsheaders.middleware.CorsMiddleware",
    "django.middleware.security.SecurityMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
]
ROOT_URLCONF = "config.urls"
TEMPLATES = [{
    "BACKEND": "django.template.backends.django.DjangoTemplates", "DIRS": [], "APP_DIRS": True,
    "OPTIONS": {"context_processors": [
        "django.template.context_processors.request",
        "django.contrib.auth.context_processors.auth",
        "django.contrib.messages.context_processors.messages"]},
}]
WSGI_APPLICATION = "config.wsgi.application"
DATABASES = {"default": {"ENGINE": "django.db.backends.sqlite3", "NAME": BASE_DIR / "db.sqlite3"}}
AUTH_PASSWORD_VALIDATORS = [
    {"NAME": "django.contrib.auth.password_validation.MinimumLengthValidator", "OPTIONS": {"min_length": 8}},
    {"NAME": "django.contrib.auth.password_validation.CommonPasswordValidator"},
    {"NAME": "django.contrib.auth.password_validation.NumericPasswordValidator"},
]
LANGUAGE_CODE = "en-us"
TIME_ZONE = "Asia/Kolkata"
USE_TZ = True
STATIC_URL = "static/"
DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"

# ---- Files & vector store ----
MEDIA_ROOT = ROOT_DIR / "knowledge_base"
MEDIA_URL = "/media/"
VECTOR_DIR = ROOT_DIR / "vector_store"
MAX_UPLOAD_MB = int(env("MAX_UPLOAD_MB", "20"))
DATA_UPLOAD_MAX_MEMORY_SIZE = MAX_UPLOAD_MB * 1024 * 1024 * 2
FILE_UPLOAD_MAX_MEMORY_SIZE = 5 * 1024 * 1024

# ---- CORS ----
CORS_ALLOWED_ORIGINS = [o.strip() for o in env(
    "CORS_ALLOWED_ORIGINS", "http://localhost:5173,http://127.0.0.1:5173").split(",") if o.strip()]

# ---- DRF ----
REST_FRAMEWORK = {
    "DEFAULT_AUTHENTICATION_CLASSES": ["rest_framework.authentication.TokenAuthentication"],
    "DEFAULT_PERMISSION_CLASSES": ["rest_framework.permissions.AllowAny"],
    "DEFAULT_THROTTLE_CLASSES": ["rest_framework.throttling.AnonRateThrottle"],
    "DEFAULT_THROTTLE_RATES": {"anon": "120/min", "login": "10/min"},
}

# ---- RAG ----
EMBEDDING_MODEL = env("EMBEDDING_MODEL", "sentence-transformers/all-MiniLM-L6-v2")
SIMILARITY_THRESHOLD = float(env("SIMILARITY_THRESHOLD", "0.30"))
TOP_K = int(env("TOP_K", "4"))
CHUNK_SIZE = int(env("CHUNK_SIZE", "800"))
CHUNK_OVERLAP = int(env("CHUNK_OVERLAP", "120"))

# ---- Nexus API (all configurable; the key is read ONLY from the environment) ----
NEXUS_API_KEY = env("NEXUS_API_KEY")
NEXUS_BASE_URL = env("NEXUS_BASE_URL")
NEXUS_CHAT_ENDPOINT = env("NEXUS_CHAT_ENDPOINT")
NEXUS_MODEL = env("NEXUS_MODEL")
NEXUS_AUTH_HEADER = env("NEXUS_AUTH_HEADER", "Authorization")
NEXUS_AUTH_PREFIX = env("NEXUS_AUTH_PREFIX", "Bearer ")
NEXUS_REQUEST_STYLE = env("NEXUS_REQUEST_STYLE", "messages")   # "messages" or "prompt"
NEXUS_RESPONSE_PATH = env("NEXUS_RESPONSE_PATH", "choices.0.message.content")
NEXUS_EXTRA_BODY = env("NEXUS_EXTRA_BODY", "{}")                # extra JSON fields merged into the request
NEXUS_TIMEOUT = int(env("NEXUS_TIMEOUT", "60"))
