export const SUGGESTIONS = [
  "What are the college working hours?",
  "What is the examination registration procedure?",
  "Where can I find the academic regulations?",
  "What are the placement eligibility criteria?",
  "What is the attendance requirement?",
  "How can I contact the placement department?",
  "What is the leave application procedure?",
];

export default function SuggestedQuestions({ onPick, disabled }) {
  return (
    <div className="chips">
      {SUGGESTIONS.map((q) => (
        <button key={q} className="chip" disabled={disabled} onClick={() => onPick(q)}>{q}</button>
      ))}
    </div>
  );
}
