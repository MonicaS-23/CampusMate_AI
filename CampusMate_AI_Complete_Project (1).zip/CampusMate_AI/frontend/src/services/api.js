// All calls go to the Django backend (proxied at /api). No secrets live in the frontend.
const BASE = import.meta.env.VITE_API_URL || "/api";
const TOKEN_KEY = "cm_admin_token";

export const getToken = () => localStorage.getItem(TOKEN_KEY);
export const setToken = (t) => localStorage.setItem(TOKEN_KEY, t);
export const clearToken = () => localStorage.removeItem(TOKEN_KEY);

export function getSessionId() {
  let id = localStorage.getItem("cm_session");
  if (!id) {
    id = (crypto.randomUUID ? crypto.randomUUID() : String(Date.now()) + Math.random().toString(36).slice(2)).replace(/[^A-Za-z0-9_-]/g, "");
    localStorage.setItem("cm_session", id);
  }
  return id;
}

async function request(path, { method = "GET", body, form, admin = false } = {}) {
  const headers = {};
  if (admin && getToken()) headers.Authorization = `Token ${getToken()}`;
  let payload;
  if (form) payload = form;
  else if (body) { headers["Content-Type"] = "application/json"; payload = JSON.stringify(body); }
  let res;
  try {
    res = await fetch(`${BASE}${path}`, { method, headers, body: payload });
  } catch {
    throw new Error("Cannot reach the server. Make sure the backend is running.");
  }
  if (res.status === 204) return null;
  let data = null;
  try { data = await res.json(); } catch { /* non-JSON */ }
  if (res.status === 401 && admin) { clearToken(); window.location.href = "/admin/login"; }
  if (!res.ok) {
    const msg = (data && (data.error || data.detail)) || `Request failed (${res.status})`;
    const err = new Error(msg); err.data = data; err.status = res.status; throw err;
  }
  return data;
}

export const api = {
  ask: (question, category) => request("/chat/", { method: "POST", body: { question, category, session_id: getSessionId() } }),
  history: () => request(`/chat/history/?session_id=${getSessionId()}`),
  clearHistory: () => request(`/chat/history/?session_id=${getSessionId()}`, { method: "DELETE" }),
  categories: () => request("/categories/"),
  login: (username, password) => request("/auth/login/", { method: "POST", body: { username, password } }),
  logout: () => request("/auth/logout/", { method: "POST", admin: true }),
  stats: () => request("/admin/stats/", { admin: true }),
  documents: () => request("/admin/documents/", { admin: true }),
  upload: (form) => request("/admin/documents/", { method: "POST", form, admin: true }),
  remove: (id) => request(`/admin/documents/${id}/`, { method: "DELETE", admin: true }),
  reindex: (id, form) => request(`/admin/documents/${id}/reindex/`, { method: "POST", form, admin: true }),
};
