from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path("django-admin/", admin.site.urls),
    path("api/auth/", include("authentication.urls")),
    path("api/", include("chatbot.urls")),
    path("api/", include("documents.urls")),
]
