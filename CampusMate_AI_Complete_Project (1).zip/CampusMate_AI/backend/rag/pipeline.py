"""End-to-end RAG: extract -> clean -> chunk -> embed -> FAISS, and retrieval."""
import logging
from django.conf import settings
from django.utils import timezone
from langchain_text_splitters import RecursiveCharacterTextSplitter
from documents.models import Chunk
from . import embeddings, store
from .extract import extract

log = logging.getLogger(__name__)


def delete_document_vectors(doc):
    ids = list(doc.chunks.values_list("id", flat=True))
    store.remove(ids)
    doc.chunks.all().delete()


def index_document(doc):
    """(Re)index one document. Never raises: failures are recorded on the document."""
    doc.status, doc.error = "processing", ""
    doc.save(update_fields=["status", "error"])
    try:
        delete_document_vectors(doc)  # clears old vectors when re-indexing
        segments = extract(doc.file.path)
        splitter = RecursiveCharacterTextSplitter(chunk_size=settings.CHUNK_SIZE,
                                                  chunk_overlap=settings.CHUNK_OVERLAP)
        rows = [Chunk(document=doc, text=t, page=s.page, section=s.section)
                for s in segments for t in splitter.split_text(s.text) if t.strip()]
        if not rows:
            raise ValueError("No readable text found (a scanned/image-only PDF needs OCR first).")
        Chunk.objects.bulk_create(rows)
        saved = list(doc.chunks.order_by("id").values_list("id", "text"))
        vectors = embeddings.embed([t for _, t in saved])
        store.add([i for i, _ in saved], vectors)
        doc.status, doc.chunk_count, doc.indexed_at = "indexed", len(saved), timezone.now()
        doc.save(update_fields=["status", "chunk_count", "indexed_at"])
    except Exception as exc:  # noqa: BLE001
        log.exception("Indexing failed for %s", doc.name)
        try:
            delete_document_vectors(doc)
        except Exception:  # noqa: BLE001
            pass
        doc.status, doc.error, doc.chunk_count = "failed", str(exc)[:500], 0
        doc.save(update_fields=["status", "error", "chunk_count"])
    return doc


def retrieve(question, category=None):
    """Semantic search. Returns [(Chunk, score)] above the similarity threshold, best first."""
    if store.total_vectors() == 0:  # empty knowledge base: nothing to retrieve
        return []
    qvec = embeddings.embed([question])[0]
    k = settings.TOP_K * (6 if category else 1)  # over-fetch when metadata-filtering
    hits = store.search(qvec, k)
    chunks = Chunk.objects.select_related("document").in_bulk([i for i, _ in hits])
    out = []
    for cid, score in hits:
        c = chunks.get(cid)
        if c is None or score < settings.SIMILARITY_THRESHOLD:
            continue
        if category and c.document.category != category:
            continue
        out.append((c, score))
    return out[:settings.TOP_K]
