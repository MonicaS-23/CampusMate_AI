import { useCallback, useEffect, useRef, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { api, clearToken } from "../services/api.js";

const fmt = (d) => (d ? new Date(d).toLocaleString() : "—");

export default function AdminDashboard() {
  const [stats, setStats] = useState(null);
  const [docs, setDocs] = useState([]);
  const [cats, setCats] = useState([]);
  const [category, setCategory] = useState("");
  const [files, setFiles] = useState([]);
  const [busy, setBusy] = useState("");
  const [msg, setMsg] = useState(null);
  const fileRef = useRef(null);
  const replaceRef = useRef(null);
  const [replaceId, setReplaceId] = useState(null);
  const nav = useNavigate();

  const refresh = useCallback(async () => {
    try {
      const [s, d] = await Promise.all([api.stats(), api.documents()]);
      setStats(s); setDocs(d);
    } catch (e) { setMsg({ type: "error", text: e.message }); }
  }, []);

  useEffect(() => { api.categories().then(setCats); refresh(); }, [refresh]);

  async function upload(e) {
    e.preventDefault();
    if (!category || !files.length) return setMsg({ type: "error", text: "Choose a category and at least one file." });
    const form = new FormData();
    form.append("category", category);
    files.forEach((f) => form.append("file", f));
    setBusy("Uploading and indexing… (the first run downloads the embedding model, which can take a few minutes)");
    setMsg(null);
    try {
      const r = await api.upload(form);
      const failed = r.results.filter((x) => !x.ok);
      setMsg({ type: failed.length ? "error" : "ok",
        text: `${r.results.length - failed.length} indexed.` + failed.map((x) => ` ${x.name}: ${x.error}`).join("") });
    } catch (err) {
      setMsg({ type: "error", text: err.data?.results ? err.data.results.map((x) => `${x.name}: ${x.error}`).join(" ") : err.message });
    }
    setFiles([]); if (fileRef.current) fileRef.current.value = "";
    setBusy(""); refresh();
  }

  async function remove(d) {
    if (!window.confirm(`Delete "${d.name}" and its embeddings?`)) return;
    setBusy("Deleting…");
    try { await api.remove(d.id); setMsg({ type: "ok", text: "Document deleted." }); }
    catch (e) { setMsg({ type: "error", text: e.message }); }
    setBusy(""); refresh();
  }

  async function reindex(d, file) {
    setBusy(`Re-indexing ${d.name}…`);
    try {
      const form = new FormData();
      if (file) form.append("file", file);
      const r = await api.reindex(d.id, form);
      setMsg({ type: r.status === "indexed" ? "ok" : "error", text: r.status === "indexed" ? "Re-indexed successfully." : r.error });
    } catch (e) { setMsg({ type: "error", text: e.message }); }
    setBusy(""); refresh();
  }

  async function logout() {
    try { await api.logout(); } catch { /* ignore */ }
    clearToken(); nav("/admin/login");
  }

  const maxDay = Math.max(1, ...(stats?.queries_per_day || []).map((d) => d.count));

  return (
    <div className="page admin">
      <header className="topbar">
        <div className="brand"><span className="logo">C</span> CampusMate AI <small>Admin Dashboard</small></div>
        <div className="top-actions">
          <Link className="btn ghost" to="/">Chatbot</Link>
          <button className="btn ghost" onClick={logout}>Logout</button>
        </div>
      </header>

      <main className="admin-body">
        {busy && <div className="alert info">{busy}</div>}
        {msg && <div className={`alert ${msg.type === "ok" ? "ok" : "error"}`}>{msg.text}</div>}

        {stats && (
          <section className="stats">
            {[["Documents", stats.documents_total], ["Indexed", stats.documents_indexed], ["Failed", stats.documents_failed],
              ["Chunks", stats.chunks_total], ["Queries", stats.queries_total], ["Answered", stats.queries_answered],
              ["Unanswered", stats.queries_unanswered]].map(([l, v]) => (
              <div className="card stat" key={l}><div className="num">{v}</div><div>{l}</div></div>
            ))}
          </section>
        )}

        <section className="grid2">
          <form className="card" onSubmit={upload}>
            <h3>Upload documents</h3>
            <label>Category
              <select value={category} onChange={(e) => setCategory(e.target.value)}>
                <option value="">Select category…</option>
                {cats.map((c) => <option key={c.value} value={c.value}>{c.label}</option>)}
              </select>
            </label>
            <label>Files (PDF, DOCX, TXT, CSV, XLSX)
              <input ref={fileRef} type="file" multiple accept=".pdf,.docx,.txt,.csv,.xlsx" onChange={(e) => setFiles([...e.target.files])} />
            </label>
            <button className="btn primary" disabled={!!busy}>Upload & index</button>
          </form>

          <div className="card">
            <h3>Queries — last 7 days</h3>
            {stats?.queries_per_day.length ? stats.queries_per_day.map((d) => (
              <div className="bar-row" key={d.day}>
                <span>{d.day.slice(5)}</span>
                <div className="bar"><div style={{ width: `${(d.count / maxDay) * 100}%` }} /></div>
                <span>{d.count}</span>
              </div>
            )) : <p className="muted">No queries yet.</p>}
          </div>
        </section>

        <section className="card">
          <h3>Knowledge base</h3>
          <input ref={replaceRef} type="file" hidden accept=".pdf,.docx,.txt,.csv,.xlsx"
            onChange={(e) => { const f = e.target.files[0]; const d = docs.find((x) => x.id === replaceId); if (f && d) reindex(d, f); e.target.value = ""; }} />
          <div className="table-wrap">
            <table>
              <thead><tr><th>Name</th><th>Category</th><th>Status</th><th>Chunks</th><th>Uploaded</th><th>Actions</th></tr></thead>
              <tbody>
                {docs.length === 0 && <tr><td colSpan="6" className="muted">No documents uploaded yet.</td></tr>}
                {docs.map((d) => (
                  <tr key={d.id}>
                    <td>{d.name}</td>
                    <td>{d.category_label}</td>
                    <td><span className={`badge ${d.status}`}>{d.status}</span>{d.error && <div className="err-small">{d.error}</div>}</td>
                    <td>{d.chunk_count}</td>
                    <td>{fmt(d.uploaded_at)}</td>
                    <td className="actions">
                      <button className="btn small" disabled={!!busy} onClick={() => reindex(d)}>Re-index</button>
                      <button className="btn small" disabled={!!busy} onClick={() => { setReplaceId(d.id); replaceRef.current.click(); }}>Replace file</button>
                      <button className="btn small danger" disabled={!!busy} onClick={() => remove(d)}>Delete</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      </main>
    </div>
  );
}
