"""Text extraction for PDF, DOCX, TXT, CSV and XLSX. Returns a list of Segment(text, page, section)."""
import os
import re
from dataclasses import dataclass
from typing import Optional


@dataclass
class Segment:
    text: str
    page: Optional[int] = None
    section: str = ""


def clean(text):
    text = text.replace("\x00", " ").replace("\r", "\n")
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def _pdf(path):
    from pypdf import PdfReader
    reader = PdfReader(path)
    return [Segment(clean(p.extract_text() or ""), page=i) for i, p in enumerate(reader.pages, start=1)]


def _docx(path):
    import docx
    d = docx.Document(path)
    segs, section, buf = [], "", []

    def flush():
        if buf:
            segs.append(Segment(clean("\n".join(buf)), section=section))
            buf.clear()

    for p in d.paragraphs:
        if not p.text.strip():
            continue
        if p.style is not None and p.style.name.lower().startswith(("heading", "title")):
            flush()
            section = p.text.strip()[:200]
        buf.append(p.text)
    flush()
    for ti, table in enumerate(d.tables, start=1):
        rows = [" | ".join(c.text.strip() for c in r.cells) for r in table.rows]
        segs.append(Segment(clean("\n".join(rows)), section=f"Table {ti}"))
    return segs


def _txt(path):
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        return [Segment(clean(f.read()))]


def _frame_to_segments(df, section, rows_per_block=15):
    df = df.fillna("").astype(str)
    lines = ["; ".join(f"{c}: {v}" for c, v in row.items() if v.strip()) for _, row in df.iterrows()]
    return [Segment(clean("\n".join(lines[i:i + rows_per_block])), section=section)
            for i in range(0, len(lines), rows_per_block)]


def _csv(path):
    import pandas as pd
    try:
        df = pd.read_csv(path)
    except UnicodeDecodeError:
        df = pd.read_csv(path, encoding="latin-1")
    return _frame_to_segments(df, "CSV data")


def _xlsx(path):
    import pandas as pd
    sheets = pd.read_excel(path, sheet_name=None)
    segs = []
    for name, df in sheets.items():
        segs += _frame_to_segments(df, f"Sheet: {name}")
    return segs


HANDLERS = {".pdf": _pdf, ".docx": _docx, ".txt": _txt, ".csv": _csv, ".xlsx": _xlsx}


def extract(path):
    ext = os.path.splitext(path)[1].lower()
    if ext not in HANDLERS:
        raise ValueError(f"Unsupported file type: {ext}")
    return [s for s in HANDLERS[ext](path) if s.text]
