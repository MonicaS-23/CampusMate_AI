import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { api, setToken } from "../services/api.js";

export default function AdminLogin() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const nav = useNavigate();

  async function submit(e) {
    e.preventDefault();
    setBusy(true); setError("");
    try {
      const r = await api.login(username, password);
      setToken(r.token);
      nav("/admin");
    } catch (err) {
      setError(err.message);
    } finally { setBusy(false); }
  }

  return (
    <div className="login-wrap">
      <form className="card login" onSubmit={submit}>
        <div className="logo big">C</div>
        <h2>Admin Login</h2>
        {error && <div className="alert error">{error}</div>}
        <label>Username<input value={username} onChange={(e) => setUsername(e.target.value)} autoFocus required /></label>
        <label>Password<input type="password" value={password} onChange={(e) => setPassword(e.target.value)} required /></label>
        <button className="btn primary" disabled={busy}>{busy ? "Signing in…" : "Sign in"}</button>
        <Link to="/" className="link">← Back to chatbot</Link>
      </form>
    </div>
  );
}
