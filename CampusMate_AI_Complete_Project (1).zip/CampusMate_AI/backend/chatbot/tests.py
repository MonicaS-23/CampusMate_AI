"""
Backend tests. Real: Django API, auth, uploads, PDF/DOCX/TXT/CSV/XLSX extraction, chunking, FAISS,
retrieval, Nexus adapter over real HTTP (against a local mock server).
Substituted: the Sentence-Transformers model is replaced by a small keyword-hash embedder so the
tests run offline. Run:  python manage.py test
"""
import json
import re
import shutil
import tempfile
import threading
import zlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from unittest import mock

import numpy as np
from django.contrib.auth.models import User
from django.core.files.uploadedfile import SimpleUploadedFile
from django.core.cache import cache
from django.test import TestCase, override_settings
from rest_framework.test import APIClient

from documents.models import Document, Chunk
from rag import store, extract

SAMPLES = Path(__file__).resolve().parents[2] / "knowledge_base" / "samples"
STOP = {"the", "is", "what", "are", "a", "of", "to", "for", "and", "in", "how", "can", "i", "do", "does", "be", "by", "an", "at", "must", "with"}


def fake_embed(texts):
    out = np.zeros((len(texts), 512), dtype="float32")
    for r, t in enumerate(texts):
        for w in re.findall(r"[a-z0-9]+", t.lower()):
            if w not in STOP:
                out[r, zlib.crc32(w.encode()) % 512] += 1
        n = np.linalg.norm(out[r])
        if n:
            out[r] /= n
    return out


class MockNexus(BaseHTTPRequestHandler):
    mode, calls = "ok", []

    def do_POST(self):
        body = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
        MockNexus.calls.append({"path": self.path, "auth": self.headers.get("Authorization"), "body": body})
        if MockNexus.mode == "401":
            self.send_response(401); self.end_headers(); return
        if MockNexus.mode == "500":
            self.send_response(500); self.end_headers(); return
        if MockNexus.mode == "429":
            self.send_response(429); self.end_headers(); return
        ctx = body["messages"][1]["content"]
        if "75%" in ctx:
            text = "Students need at least 75% attendance. (from context)"
        elif "register" in ctx:
            text = "Register online through the student portal 15 days before exams. (from context)"
        else:
            text = "I couldn't find this information in the available college documents. Please contact the concerned department for confirmation."
        out = json.dumps({"choices": [{"message": {"content": text}}]}).encode()
        self.send_response(200); self.send_header("Content-Type", "application/json"); self.end_headers(); self.wfile.write(out)

    def log_message(self, *a):
        pass


class CampusMateTests(TestCase):
    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.tmp = Path(tempfile.mkdtemp())
        cls.server = ThreadingHTTPServer(("127.0.0.1", 0), MockNexus)
        threading.Thread(target=cls.server.serve_forever, daemon=True).start()
        cls.url = f"http://127.0.0.1:{cls.server.server_address[1]}"
        cls.ov = override_settings(
            MEDIA_ROOT=cls.tmp / "media", VECTOR_DIR=cls.tmp / "vec", SIMILARITY_THRESHOLD=0.15,
            NEXUS_API_KEY="test-secret-key", NEXUS_BASE_URL=cls.url, NEXUS_CHAT_ENDPOINT="/v1/chat",
            NEXUS_MODEL="test-model", MAX_UPLOAD_MB=1)
        cls.ov.enable()
        cls.patch = mock.patch("rag.embeddings.embed", side_effect=fake_embed)
        cls.patch.start()

    @classmethod
    def tearDownClass(cls):
        cls.patch.stop(); cls.ov.disable(); cls.server.shutdown()
        shutil.rmtree(cls.tmp, ignore_errors=True)
        super().tearDownClass()

    def setUp(self):
        MockNexus.mode, MockNexus.calls = "ok", []
        cache.clear()  # reset throttling between tests
        shutil.rmtree(self.tmp / "vec", ignore_errors=True)  # DB is rolled back per test, so reset FAISS too
        User.objects.create_user("admin", password="Str0ng-Pass!9", is_staff=True)
        User.objects.create_user("student", password="Str0ng-Pass!9")
        self.c = APIClient()
        tok = self.c.post("/api/auth/login/", {"username": "admin", "password": "Str0ng-Pass!9"}, format="json").data["token"]
        self.admin = APIClient(); self.admin.credentials(HTTP_AUTHORIZATION=f"Token {tok}")

    def upload(self, fname, category):
        data = (SAMPLES / fname).read_bytes()
        return self.admin.post("/api/admin/documents/", {"file": SimpleUploadedFile(fname, data), "category": category}, format="multipart")

    def upload_all(self):
        for f, c in [("SAMPLE_attendance_policy.txt", "attendance_rules"), ("SAMPLE_academic_regulations.pdf", "academic_regulations"),
                     ("SAMPLE_placement_and_leave.docx", "placement_guidelines"), ("SAMPLE_contact_information.csv", "contact_information"),
                     ("SAMPLE_timetable.xlsx", "timetables")]:
            self.assertEqual(self.upload(f, c).status_code, 201, f)

    # ---- auth & permissions ----
    def test_auth(self):
        self.assertEqual(self.c.post("/api/auth/login/", {"username": "admin", "password": "bad"}, format="json").status_code, 401)
        self.assertEqual(self.c.post("/api/auth/login/", {"username": "student", "password": "Str0ng-Pass!9"}, format="json").status_code, 401)
        self.assertEqual(self.c.get("/api/admin/documents/").status_code, 401)
        self.assertEqual(self.c.get("/api/admin/stats/").status_code, 401)
        self.assertEqual(self.c.delete("/api/admin/documents/1/").status_code, 401)
        self.assertEqual(self.admin.get("/api/auth/me/").data["username"], "admin")

    def test_health(self):
        r = self.c.get("/api/health/")
        self.assertEqual(r.status_code, 200); self.assertTrue(r.data["nexus_configured"])
        self.assertNotIn("test-secret-key", json.dumps(r.data))

    # ---- extraction ----
    def test_extraction_all_formats(self):
        pdf = extract.extract(str(SAMPLES / "SAMPLE_academic_regulations.pdf"))
        self.assertEqual([s.page for s in pdf], [1, 2]); self.assertIn("register", pdf[1].text)
        dx = extract.extract(str(SAMPLES / "SAMPLE_placement_and_leave.docx"))
        self.assertTrue(any("CGPA" in s.text and "Placement" in s.section for s in dx))
        self.assertIn("75%", extract.extract(str(SAMPLES / "SAMPLE_attendance_policy.txt"))[0].text)
        self.assertIn("Email", extract.extract(str(SAMPLES / "SAMPLE_contact_information.csv"))[0].text)
        self.assertIn("Monday", extract.extract(str(SAMPLES / "SAMPLE_timetable.xlsx"))[0].text)

    # ---- upload / index ----
    def test_upload_index_validation_duplicates(self):
        self.upload_all()
        self.assertEqual(Document.objects.filter(status="indexed").count(), 5)
        self.assertEqual(store.total_vectors(), Chunk.objects.count())
        self.assertEqual(self.upload("SAMPLE_attendance_policy.txt", "attendance_rules").status_code, 409)  # duplicate
        bad = self.admin.post("/api/admin/documents/", {"file": SimpleUploadedFile("x.exe", b"abc"), "category": "timetables"}, format="multipart")
        self.assertEqual(bad.status_code, 400)
        big = self.admin.post("/api/admin/documents/", {"file": SimpleUploadedFile("big.txt", b"a" * (2 * 1024 * 1024)), "category": "timetables"}, format="multipart")
        self.assertEqual(big.status_code, 400)
        nocat = self.admin.post("/api/admin/documents/", {"file": SimpleUploadedFile("a.txt", b"hello")}, format="multipart")
        self.assertEqual(nocat.status_code, 400)
        empty_pdf = self.admin.post("/api/admin/documents/", {"file": SimpleUploadedFile("bad.pdf", b"not a pdf"), "category": "timetables"}, format="multipart")
        self.assertEqual(empty_pdf.status_code, 400)
        self.assertEqual(Document.objects.get(name="bad.pdf").status, "failed")
        stats = self.admin.get("/api/admin/stats/").data
        self.assertEqual(stats["documents_indexed"], 5); self.assertEqual(stats["documents_failed"], 1)

    # ---- end-to-end RAG ----
    def test_chat_end_to_end_with_sources(self):
        self.upload_all()
        r = self.c.post("/api/chat/", {"question": "What is the attendance requirement?", "session_id": "sess-12345678"}, format="json")
        self.assertEqual(r.status_code, 200, r.data)
        self.assertTrue(r.data["answered"]); self.assertIn("75%", r.data["answer"])
        self.assertEqual(r.data["sources"][0]["document"], "SAMPLE_attendance_policy.txt")
        call = MockNexus.calls[-1]
        self.assertEqual(call["auth"], "Bearer test-secret-key"); self.assertEqual(call["path"], "/v1/chat")
        self.assertIn("75%", call["body"]["messages"][1]["content"])
        # PDF page number preserved
        r = self.c.post("/api/chat/", {"question": "How do I register for examinations?", "session_id": "sess-12345678"}, format="json")
        src = [s for s in r.data["sources"] if s["document"].endswith(".pdf")]
        self.assertTrue(src and src[0]["page"] == 2, r.data)
        # history + clear
        self.assertEqual(len(self.c.get("/api/chat/history/?session_id=sess-12345678").data), 2)
        self.assertEqual(self.c.delete("/api/chat/history/?session_id=sess-12345678").status_code, 204)
        self.assertEqual(len(self.c.get("/api/chat/history/?session_id=sess-12345678").data), 0)

    def test_metadata_filter(self):
        self.upload_all()
        r = self.c.post("/api/chat/", {"question": "attendance 75% examination", "session_id": "sess-12345678", "category": "timetables"}, format="json")
        self.assertFalse(r.data["answered"])

    def test_unknown_question_does_not_call_llm(self):
        self.upload_all()
        r = self.c.post("/api/chat/", {"question": "quantum chromodynamics banana", "session_id": "sess-12345678"}, format="json")
        self.assertFalse(r.data["answered"]); self.assertTrue(r.data["answer"].startswith("I couldn't find this information"))
        self.assertEqual(r.data["sources"], []); self.assertEqual(MockNexus.calls, [])

    def test_chat_validation(self):
        self.assertEqual(self.c.post("/api/chat/", {"question": "", "session_id": "sess-12345678"}, format="json").status_code, 400)
        self.assertEqual(self.c.post("/api/chat/", {"question": "hi", "session_id": "x"}, format="json").status_code, 400)

    # ---- Nexus error handling ----
    def test_nexus_errors(self):
        self.upload_all()
        q = {"question": "What is the attendance requirement?", "session_id": "sess-12345678"}
        for mode, status, code in [("401", 502, "invalid_api_key"), ("500", 503, "service_unavailable"), ("429", 429, "rate_limited")]:
            MockNexus.mode = mode
            r = self.c.post("/api/chat/", q, format="json")
            self.assertEqual((r.status_code, r.data["code"]), (status, code))
        with override_settings(NEXUS_BASE_URL="http://127.0.0.1:1"):
            self.assertEqual(self.c.post("/api/chat/", q, format="json").data["code"], "network_error")
        with override_settings(NEXUS_API_KEY=""):
            r = self.c.post("/api/chat/", q, format="json")
            self.assertEqual((r.status_code, r.data["code"]), (503, "not_configured"))
        MockNexus.mode = "ok"
        with override_settings(NEXUS_RESPONSE_PATH="wrong.path"):
            self.assertEqual(self.c.post("/api/chat/", q, format="json").data["code"], "bad_response")

    # ---- delete / re-index ----
    def test_delete_and_reindex(self):
        self.upload_all()
        doc = Document.objects.get(name="SAMPLE_attendance_policy.txt")
        before = store.total_vectors(); n = doc.chunk_count
        r = self.admin.post(f"/api/admin/documents/{doc.id}/reindex/")
        self.assertEqual(r.data["status"], "indexed"); self.assertEqual(store.total_vectors(), before)  # no duplicates
        upd = SimpleUploadedFile("SAMPLE_attendance_policy.txt", b"Updated rule: minimum attendance is 80% for all courses.")
        r = self.admin.post(f"/api/admin/documents/{doc.id}/reindex/", {"file": upd}, format="multipart")
        self.assertEqual(r.data["status"], "indexed")
        q = self.c.post("/api/chat/", {"question": "attendance minimum", "session_id": "sess-12345678"}, format="json")
        self.assertIn("attendance", MockNexus.calls[-1]["body"]["messages"][1]["content"]); self.assertNotIn("65%", MockNexus.calls[-1]["body"]["messages"][1]["content"])
        self.assertEqual(self.admin.delete(f"/api/admin/documents/{doc.id}/").status_code, 204)
        self.assertEqual(store.total_vectors(), Chunk.objects.count())
        self.assertFalse(Document.objects.filter(pk=doc.pk).exists())
        # student cannot delete
        stu = APIClient(); stu.force_authenticate(User.objects.get(username="student"))
        other = Document.objects.first()
        self.assertIn(stu.delete(f"/api/admin/documents/{other.id}/").status_code, (401, 403))
        self.assertTrue(Document.objects.filter(pk=other.pk).exists())
