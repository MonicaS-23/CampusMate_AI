from django.urls import path
from . import views

urlpatterns = [
    path("chat/", views.ChatView.as_view()),
    path("chat/history/", views.HistoryView.as_view()),
    path("health/", views.HealthView.as_view()),
]
