from django.db import models

CATEGORIES = [
    ("college_information", "College Information"),
    ("academic_regulations", "Academic Regulations"),
    ("department_information", "Department Information"),
    ("timetables", "Timetables"),
    ("examination_schedules", "Examination Schedules"),
    ("attendance_rules", "Attendance Rules"),
    ("placement_guidelines", "Placement Guidelines"),
    ("internship_information", "Internship Information"),
    ("scholarship_information", "Scholarship Information"),
    ("student_services", "Student Services"),
    ("leave_procedures", "Leave Procedures"),
    ("contact_information", "Contact Information"),
]


class Document(models.Model):
    STATUS = [("pending", "Pending"), ("processing", "Processing"), ("indexed", "Indexed"), ("failed", "Failed")]
    name = models.CharField(max_length=255)
    file = models.FileField(upload_to="uploads/")
    category = models.CharField(max_length=40, choices=CATEGORIES)
    file_hash = models.CharField(max_length=64, unique=True)   # prevents duplicate indexing
    status = models.CharField(max_length=12, choices=STATUS, default="pending")
    error = models.TextField(blank=True)
    chunk_count = models.IntegerField(default=0)
    uploaded_at = models.DateTimeField(auto_now_add=True)
    indexed_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["-uploaded_at"]

    def __str__(self):
        return self.name


class Chunk(models.Model):
    """The primary key of a Chunk is also its id inside the FAISS index."""
    document = models.ForeignKey(Document, related_name="chunks", on_delete=models.CASCADE)
    text = models.TextField()
    page = models.IntegerField(null=True, blank=True)
    section = models.CharField(max_length=200, blank=True)
