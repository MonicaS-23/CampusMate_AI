export default function Typing() {
  return (
    <div className="msg ai">
      <div className="avatar">AI</div>
      <div className="bubble"><span className="dots"><i /><i /><i /></span></div>
    </div>
  );
}
